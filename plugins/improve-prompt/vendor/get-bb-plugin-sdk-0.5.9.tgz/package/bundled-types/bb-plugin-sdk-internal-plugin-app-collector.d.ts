// Portable type declarations for `@get-bb/plugin-sdk`. Unpublished BB
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @bb/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the BB repo
// and read the real source: https://github.com/get-bb/bb

import { z } from 'zod';
import { ExperimentalSidebarFooterActionContext, ExperimentalSidebarFooterItemRegistration, PluginHomepageSectionRegistration, PluginSettingsSectionRegistration, ExperimentalAppOverlayRegistration, PluginNavPanelRegistration, PluginThreadPanelActionRegistration, PluginNewThreadPanelActionRegistration, ComposerCustomization, PluginPendingInteractionRegistration, PluginSidebarFooterActionRegistration, ExperimentalSidebarNavigationRegistration, PluginThreadListRegistration, PluginThreadHeaderActionRegistration, ExperimentalPluginBrowserToolbarActionRegistration, PluginFileOpenerRegistration, PluginSourceCodeRendererRegistration, PluginDiffRendererRegistration, PluginMessageDirectiveRegistration, PluginMessageActionRegistration, PluginCommandRegistration, PluginProviderIconRegistration, ExperimentalIconRegistration, PluginTimelineRendererRegistration, PluginEnvironmentProviderInputsRegistration, PluginMachineProviderInputsRegistration, PluginContentScriptRegistration, PluginAppDefinition } from '@get-bb/plugin-sdk';

type ExperimentalSidebarFooterCommandKind = "close" | "open" | "toggle";
interface ExperimentalSidebarFooterRuntimeSnapshot {
    command: {
        sequence: number;
        kind: ExperimentalSidebarFooterCommandKind;
    } | null;
}
interface ExperimentalSidebarFooterItemRuntime {
    subscribe(listener: () => void): () => void;
    getSnapshot(): ExperimentalSidebarFooterRuntimeSnapshot;
    acknowledgeCommand(sequence: number): void;
}
type CollectedExperimentalSidebarFooterItem = ExperimentalSidebarFooterItemRegistration & {
    runtime: ExperimentalSidebarFooterItemRuntime;
};
type CollectedManagedSidebarFooterItem = CollectedExperimentalSidebarFooterItem & {
    source: "experimental_sidebarFooter";
};
interface CollectedCompatibilitySidebarFooterItem {
    source: "sidebarFooterAction";
    id: string;
    label: string;
    icon: string;
    kind: "action";
    onActivate(context: ExperimentalSidebarFooterActionContext): void | Promise<void>;
    runtime: ExperimentalSidebarFooterItemRuntime;
}
type CollectedSidebarFooterItem = CollectedCompatibilitySidebarFooterItem | CollectedManagedSidebarFooterItem;
declare function adaptSidebarFooterAction(registration: PluginSidebarFooterActionRegistration): CollectedCompatibilitySidebarFooterItem;
type CollectedPluginProviderIconRegistration = Omit<PluginProviderIconRegistration, "providerKind"> & {
    providerKind: PluginProviderIconRegistration["providerKind"] | "all";
};
/** Validated registrations produced by one plugin app setup execution. */
declare const commandShortcutSchema: z.ZodObject<{
    alt: z.ZodDefault<z.ZodBoolean>;
    control: z.ZodDefault<z.ZodBoolean>;
    key: z.ZodString;
    meta: z.ZodDefault<z.ZodBoolean>;
    mod: z.ZodDefault<z.ZodBoolean>;
    shift: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
interface CollectedPluginCommandRegistration extends Omit<PluginCommandRegistration, "defaultShortcut"> {
    defaultShortcut: z.infer<typeof commandShortcutSchema> | null;
}
interface CollectedPluginAppRegistrations {
    homepageSections: PluginHomepageSectionRegistration[];
    settingsSections: PluginSettingsSectionRegistration[];
    appOverlays: ExperimentalAppOverlayRegistration[];
    navPanels: PluginNavPanelRegistration[];
    threadPanelActions: PluginThreadPanelActionRegistration[];
    newThreadPanelActions: PluginNewThreadPanelActionRegistration[];
    composerCustomizations: ComposerCustomization[];
    pendingInteractions: PluginPendingInteractionRegistration[];
    sidebarFooterActions: PluginSidebarFooterActionRegistration[];
    experimentalSidebarFooterItems: CollectedExperimentalSidebarFooterItem[];
    experimentalSidebarNavigations: ExperimentalSidebarNavigationRegistration[];
    threadLists: PluginThreadListRegistration[];
    threadHeaderActions: PluginThreadHeaderActionRegistration[];
    browserToolbarActions: ExperimentalPluginBrowserToolbarActionRegistration[];
    fileOpeners: PluginFileOpenerRegistration[];
    sourceCodeRenderers: PluginSourceCodeRendererRegistration[];
    diffRenderers: PluginDiffRendererRegistration[];
    messageDirectives: PluginMessageDirectiveRegistration[];
    messageActions: PluginMessageActionRegistration[];
    commandPaletteActions: CollectedPluginCommandRegistration[];
    providerIcons: CollectedPluginProviderIconRegistration[];
    icons: ExperimentalIconRegistration[];
    timelineRenderers: PluginTimelineRendererRegistration[];
    environmentProviderInputs: PluginEnvironmentProviderInputsRegistration[];
    machineProviderInputs: PluginMachineProviderInputsRegistration[];
    contentScripts: PluginContentScriptRegistration[];
}
declare function getCollectedSidebarFooterItems(registrations: object): readonly CollectedSidebarFooterItem[] | null;
/**
 * Run a plugin app definition against the canonical validating collector.
 * Both the BB app and the public test harness use this implementation so a
 * registration accepted by one cannot be rejected or normalized differently
 * by the other.
 */
declare function collectPluginAppRegistrations(definition: PluginAppDefinition, onComposerCustomizationRejected?: (reason: string) => void): CollectedPluginAppRegistrations;

export { adaptSidebarFooterAction, collectPluginAppRegistrations, getCollectedSidebarFooterItems };
export type { CollectedCompatibilitySidebarFooterItem, CollectedExperimentalSidebarFooterItem, CollectedManagedSidebarFooterItem, CollectedPluginAppRegistrations, CollectedPluginCommandRegistration, CollectedPluginProviderIconRegistration, CollectedSidebarFooterItem, ExperimentalSidebarFooterCommandKind, ExperimentalSidebarFooterItemRuntime, ExperimentalSidebarFooterRuntimeSnapshot };
